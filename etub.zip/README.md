# etub
EasyToUseBlog

Created by one person. For people out there without greater knowlage of computer systems but with the will by having an own simple to use and nice BLOG system.

Right NOW it is in a vary early stage! There are issues with security and with not yet implimented stuff like image support and more. So use as it right now at your own risk!
