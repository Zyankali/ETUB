<?php
session_start();



// Alle bisherrigen Sessions Löschen und Benutzer vom Installer verabschieden.

session_unset();


session_destroy();
?>


<!DOCTYPE html>
<html lang="de">
<head>
<title>etub_install</title>
<meta name="description" content="Installation des ETUBs">
<meta name="keywords" content="install_etub">
<meta name="author" content="silentsands">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

</head>
<body text="#000000" bgcolor="#F4F8F4" link="#FF0000" alink="#FF0000" vlink="#FF0000">
<font size="+4" face="VERDANA,ARIAL,HELVETICA"><p align="center">Installer</p></font>
<fieldset>
<legend>ETUB Abschluss</legend>

<p align="left">Ab hier endet nun der Installer und somit die Installationsroutine.
<br>
<br>
Sie k&ouml;nnen nun auf den unten stehenden Verweis/Link klicken um auf die Hauptseite ihres Blogs zu gelangen.<br>
<br>
 </p>

 <h4><a class="normallink" href="../index.php" name="hauptseite" title="Abschluss">Abschluss</a></h4>


</fieldset>


</body>
</html>