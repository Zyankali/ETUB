
<!DOCTYPE html>
<html lang="de">
<head>
<title>Benutzer</title>
<meta name="description" content="installer index">
<meta name="keywords" content="installer">
<meta name="author" content="silentsands">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

</head>
<body text="#000000" bgcolor="#F4F8F4" link="#FF0000" alink="#FF0000" vlink="#FF0000">
<font size="+4" face="VERDANA,ARIAL,HELVETICA"><p align="center">Installer</p></font>


<form action="datenbank_config.php" method="post">
<fieldset>
<legend>Logindaten:</legend>
Benutzer:<br>
<input type = "text" name="user" placeholder="Benutzer"><br><br>
Passwort:<br>
<input type = "password" name="password" placeholder="Passwort"><br><br>
Passwort nochmals eingeben:<br>
<input type = "password" name="password_" placeholder="Passwort"><br><br>
<input type = "submit" value="Weiter">

<h4><a class="normallink" href="index.php" name="installer" title="Abrechen">Abrechen</a></h4>
</fieldset>
</form>



</body>
</html>